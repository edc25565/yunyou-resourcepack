// 雲遊介面（YunyouHud）：把介面文字移到畫面各角落。插在 core/text.vsh 的介面分支（IS_GUI）裡。
// 外掛用 Boss 血條標題送出整串介面，每個字的顏色是編碼：
//   G = 251（標記）
//   B = 錨點(高 3 位元) | 垂直位移/4(低 5 位元)
//   R = 調色盤編號(高 6 位元：0～15 原尺寸，32～47 放大兩倍) | 垂直位移餘數(低 2 位元)
// 錨點：0 左上 1 上中 2 右上 3 小地圖正下方 4 小地圖正上方 5 左下 6 下中 7 右下
// 外掛把整串的總寬度補成 0，所以文字的起點就在畫面正中央，往左右移多少就是到錨點的距離。
// Boss 血條標題的文字行頂端在 y = 3；位移後字的頂端 = 錨點基準 + 垂直位移（0～127）。
// 錨點基準：上方 0；小地圖下方＝地圖底；小地圖上方＝地圖頂 - 12；下方 = 畫面高 - 168（圖可以往下超出 127）。
// 放大兩倍時，以「錨點的水平中心、這一行的頂端」為中心放大。
if (ProjMat[3][3] == 1.0) {
    ivec3 yyc = ivec3(round(Color.rgb * 255.0));
    if (yyc.g == 251) {
        const vec3 YY_PALETTE[16] = vec3[](
            vec3(1.0),                                  // 0 白
            vec3(0.910, 0.761, 0.416),                  // 1 金
            vec3(0.490, 0.890, 0.416),                  // 2 綠（血）
            vec3(0.353, 0.722, 1.0),                    // 3 藍（內力）
            vec3(1.0, 0.824, 0.290),                    // 4 黃（飽食、任務）
            vec3(0.667),                                // 5 灰
            vec3(0.333),                                // 6 深灰
            vec3(1.0, 0.353, 0.353),                    // 7 紅
            vec3(0.165),                                // 8 墨色（淺底上的字）
            vec3(1.0, 0.914, 0.659),                    // 9 淡金
            vec3(0.478, 0.306, 0.0),                    // 10 褐金
            vec3(0.0),                                  // 11 黑
            vec3(0.902, 0.361, 0.180),                  // 12 橘紅（血量偏低）
            vec3(0.800, 0.800, 0.780),                  // 13 淺灰
            vec3(0.596, 0.847, 1.0),                    // 14 淡藍
            vec3(0.353, 0.212, 0.031)                   // 15 深褐（描邊）
        );
        int yyAnchor = yyc.b >> 5;
        int yyPal = yyc.r >> 2;
        float yyScaleUp = yyPal >= 32 ? 2.0 : 1.0;
        yyPal = yyPal & 15;
        float yyOff = float((yyc.b & 31) * 4 + (yyc.r & 3));
        float yyW = 2.0 / ProjMat[0][0];
        float yyH = -2.0 / ProjMat[1][1];
        float yyCenter = floor(yyW / 2.0);
        // 相對於「整串起點（畫面正中央）、文字行頂端」的位置，放大的字再乘兩倍
        vec2 yyRel = vec2(Position.x - yyCenter, Position.y - 3.0) * yyScaleUp;
        float yyX;
        float yyBase;
        if (yyAnchor == 3 || yyAnchor == 4) {
#ifdef MAP_OFFSET
            vec2 yyMapOff = MAP_OFFSET;
            vec2 yyMapSize = MAP_SIZE;
#else
            vec2 yyMapOff = vec2(60.0);
            vec2 yyMapSize = vec2(256.0);
#endif
            float yyScale = ScreenSize.y / yyH;
            yyX = floor(yyW - (yyMapOff.x + yyMapSize.x * 0.5) / yyScale);
            yyBase = yyAnchor == 3 ? ceil((yyMapOff.y + yyMapSize.y) / yyScale) : floor(yyMapOff.y / yyScale) - 12.0;
        } else {
            if (yyAnchor == 0 || yyAnchor == 5) yyX = 0.0;
            else if (yyAnchor == 2 || yyAnchor == 7) yyX = yyW;
            else yyX = yyCenter;
            yyBase = yyAnchor <= 2 ? 0.0 : yyH - 168.0;
        }
        vec3 yyPos = vec3(yyX + yyRel.x, yyBase + yyOff + yyRel.y, Position.z);
        gl_Position = ProjMat * ModelViewMat * vec4(yyPos, 1.0);
        vertexColor = vec4(YY_PALETTE[yyPal], Color.a);
    }
}
