// 雲遊介面（YunyouHud）：把介面文字移到畫面各角落。插在 core/text.vsh 的介面分支（IS_GUI）裡。
// 外掛用 Boss 血條標題送出整串介面，每個字的顏色是編碼：
//   G = 251（標記）
//   B = 錨點(高 3 位元) | 垂直位移/4(低 5 位元)
//   R = 調色盤編號(高 6 位元：0～15 原尺寸，32～47 放大兩倍，48～63 全螢幕圖) | 垂直位移餘數(低 2 位元)
// 錨點：0 左上 1 上中 2 右上 3 小地圖正下方 4 小地圖正上方 5 左下 6 下中 7 右下
// 外掛把整串的總寬度補成 0，所以文字的起點就在畫面正中央，往左右移多少就是到錨點的距離。
// Boss 血條標題的文字行頂端在 y = 3；位移後字的頂端 = 錨點基準 + 垂直位移（0～127）。
// 錨點基準：上方 0；小地圖下方＝地圖底；小地圖上方＝地圖頂 - 12；下方 = 畫面高 - 300（位移每格 2 像素）。
// 放大兩倍時，以「錨點的水平中心、這一行的頂端」為中心放大。
if (ProjMat[3][3] == 1.0) {
    ivec3 yyc = ivec3(round(Color.rgb * 255.0));
    // 容器畫面的標題（原版固定深灰 404040）：底色換成墨色後看不到，改成淡金
    if (yyc == ivec3(64, 64, 64)) vertexColor = vec4(0.91, 0.80, 0.55, Color.a);
    if (yyc.g == 251 || yyc.g == 250) {
        const vec3 YY_PALETTE[16] = vec3[](
            vec3(1.0),                                  // 0 白
            vec3(0.910, 0.761, 0.416),                  // 1 金
            vec3(0.490, 0.890, 0.416),                  // 2 綠（血）
            vec3(0.353, 0.722, 1.0),                    // 3 藍（內力）
            vec3(1.0, 0.824, 0.290),                    // 4 黃（飽食、任務）
            vec3(0.667),                                // 5 灰
            vec3(0.333),                                // 6 深灰
            vec3(1.0, 0.353, 0.353),                    // 7 紅
            vec3(0.165),                                // 8 墨色（淺底上的字）
            vec3(1.0, 0.914, 0.659),                    // 9 淡金
            vec3(0.478, 0.306, 0.0),                    // 10 褐金
            vec3(0.0),                                  // 11 黑
            vec3(0.902, 0.361, 0.180),                  // 12 橘紅（血量偏低）
            vec3(0.800, 0.800, 0.780),                  // 13 淺灰
            vec3(0.596, 0.847, 1.0),                    // 14 淡藍
            vec3(0.353, 0.212, 0.031)                   // 15 深褐（描邊）
        );
        int yyAnchor = yyc.b >> 5;
        int yyPal = yyc.r >> 2;
        // 16～31：箱子畫面標題用（任務日誌）。水平位置照原本（標題從畫面左上 +8 開始排），
        // 垂直改成「標題行頂端 - 6 = 畫面頂」再往下 (位移×2 - 64)，範圍 -64～190，間隔 2
        if (yyPal >= 16 && yyPal < 32) {
            float yyOff2 = float((yyc.b & 31) * 4 + (yyc.r & 3)) * 2.0 - 64.0;
            gl_Position = ProjMat * ModelViewMat * vec4(Position.x, Position.y - 6.0 + yyOff2, Position.z, 1.0);
            vertexColor = vec4(YY_PALETTE[yyPal & 15], Color.a);
        } else {
        // 48～63：全螢幕圖（以 192×108 介面單位排版，拉滿整個畫面）；32～47：放大兩倍
        bool yyFull = yyPal >= 48;
        float yyScaleUp = (yyPal >= 32 && !yyFull) ? 2.0 : 1.0;
        yyPal = yyPal & 15;
        float yyOff = float((yyc.b & 31) * 4 + (yyc.r & 3));
        float yyW = 2.0 / ProjMat[0][0];
        float yyH = -2.0 / ProjMat[1][1];
        float yyCenter = floor(yyW / 2.0);
        // 相對於「整串起點（畫面正中央）、文字行頂端」的位置，放大的字再乘兩倍
        vec2 yyRel = vec2(Position.x - yyCenter, Position.y - 3.0) * yyScaleUp;
        float yyX;
        float yyBase;
        if (yyc.g == 250) {
            // 第二組錨點（G = 250）：0 左中、1 右中、2 畫面正中（準心）；基準 = 畫面高/2 - 64
            yyX = yyAnchor == 0 ? 0.0 : (yyAnchor == 1 ? yyW : yyCenter);
            yyBase = floor(yyH / 2.0) - 64.0;
        } else if (yyAnchor == 3 || yyAnchor == 4) {
#ifdef MAP_OFFSET
            vec2 yyMapOff = MAP_OFFSET;
            vec2 yyMapSize = MAP_SIZE;
#else
            vec2 yyMapOff = vec2(60.0);
            vec2 yyMapSize = vec2(256.0);
#endif
            float yyScale = ScreenSize.y / yyH;
            yyX = floor(yyW - (yyMapOff.x + yyMapSize.x * 0.5) / yyScale);
            // 地圖下方那一塊（羅盤左右各 90 格）在窄畫面會超出右邊：往左靠，至少留 94 格
            if (yyAnchor == 3) yyX = min(yyX, yyW - 94.0);
            yyBase = yyAnchor == 3 ? ceil((yyMapOff.y + yyMapSize.y) / yyScale) : floor(yyMapOff.y / yyScale) - 12.0;
        } else {
            if (yyAnchor == 0 || yyAnchor == 5) yyX = 0.0;
            else if (yyAnchor == 2 || yyAnchor == 7) yyX = yyW;
            else yyX = yyCenter;
            // 下方錨點：基準畫面高 - 256，位移每格 2 像素（範圍 0～254），對話框選項才放得下
            if (yyAnchor <= 2) yyBase = 0.0;
            else { yyBase = yyH - 300.0; yyOff *= 2.0; }
        }
        vec3 yyPos = vec3(yyX + yyRel.x, yyBase + yyOff + yyRel.y, Position.z);
        if (yyFull) yyPos.xy = vec2(yyRel.x * yyW / 192.0, (yyOff + yyRel.y) * yyH / 108.0);
        gl_Position = ProjMat * ModelViewMat * vec4(yyPos, 1.0);
        vertexColor = vec4(YY_PALETTE[yyPal], Color.a);
        }
    }
}
